@XmlJavaTypeAdapter(XMLDateAdapter.class)
package com.testdroid.api.model;

import com.testdroid.api.XMLDateAdapter;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

