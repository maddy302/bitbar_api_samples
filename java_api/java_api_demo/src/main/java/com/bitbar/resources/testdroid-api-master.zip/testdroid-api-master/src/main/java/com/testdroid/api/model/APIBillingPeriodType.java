package com.testdroid.api.model;

/**
 * @author Damian Sniezek <damian.sniezek@bitbar.com>
 */
public enum APIBillingPeriodType {
    BUY,
    CHARGE,
    CANCEL
}
